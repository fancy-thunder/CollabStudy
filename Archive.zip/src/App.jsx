import { useState } from "react";
import SignIn from "./pages/SignIn/SignIn.jsx";
import SignUp from "./pages/SignUp/SignUp.jsx";
import Dashboard from "./pages/Dashboard/Dashboard.jsx";

function App() {
  return (
    <>
      <SignIn/>
      {/* <SignUp></SignUp> */}
      {/* <Dashboard/> */}
    </>
  );
}

export default App;
